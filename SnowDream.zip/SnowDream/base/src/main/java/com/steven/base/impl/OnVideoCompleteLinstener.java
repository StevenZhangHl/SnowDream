package com.steven.base.impl;

/**
 * @user steven
 * @createDate 2019/6/26 15:46
 * @description 自定义
 */
public interface OnVideoCompleteLinstener {
    void onComplete();
}
