package com.steven.base.app;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * @user steven
 * @createDate 2019/3/4 10:49
 * @description 自定义
 */
@GlideModule
public class MyAppGlideModule extends AppGlideModule {
}
