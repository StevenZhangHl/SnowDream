package com.steven.base.util.RecyclerView;

/**
 * @user steven
 * @createDate 2019/4/3 10:07
 * @description Item移动后 触发
 */
public interface OnItemMoveListener {
    void onItemMove(int fromPosition, int toPosition);
}
