package com.steven.base.mvp;

/**
 * @author ChenYangYi
 * @date 2018/7/31
 * Model基类
 */
public interface BaseModel {
}
