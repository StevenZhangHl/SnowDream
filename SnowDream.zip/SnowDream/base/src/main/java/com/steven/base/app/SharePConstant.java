package com.steven.base.app;

/**
 * @user steven
 * @createDate 2019/3/4 16:03
 * @description 自定义
 */
public class SharePConstant {
    public static final String KEY_DREAM_DATA = "dream_data";
    public static final String KEY_USER_INFO_DATA = "user_info_data";
    public static final String KEY_USER_ADDRESS_DATA = "user_address_data";
    public static final String KEY_SIGN_IN_NOTES = "key_sign_in_notes";
    /**
     * 用户动态列表
     */
    public static final String KEY_USER_DYNAMIC_LIST = "key_user_dynamic_list";
}
