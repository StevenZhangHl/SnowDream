package com.steven.base.impl;

import android.view.View;

/**
 * @user steven
 * @createDate 2019/3/28 13:24
 * @description 自定义
 */
public interface SpanIndexListener {
    void onSpanIndexChange(View view, int spanIndex);
}
