package com.steven.base.net;

/**
 * @user steven
 * @createDate 2019/2/20 13:43
 * @description 自定义
 */
public class Url {
    public static final String BASE_URL = "http://v.juhe.cn/";
    public static final String BASE_JUHE_DEV = "http://web.juhe.cn:8080/";
    public static final String BASE_JUHE_DEV_NAME = "base_juhe_dev_name";
}
