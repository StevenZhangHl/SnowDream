package com.steven.base.rx;

/**
 * @author :ChenYangYi
 * @time :2018/4/17
 * @desc :服务器请求异常
 */
public class HRException extends Exception {

    public HRException(String msg) {
        super(msg);
    }

}
