package com.snow.app;

import com.steven.base.app.BaseApp;

/**
 * @user steven
 * @createDate 2019/6/24 10:44
 * @description 自定义
 */
public class LaucherApp extends BaseApp {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
