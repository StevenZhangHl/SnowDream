package com.example.zealience.oneiromancy.mvp.model;

import com.example.zealience.oneiromancy.mvp.contract.VRcontract;

/**
 * @user steven
 * @createDate 2019/2/27 13:38
 * @description 自定义
 */
public class VRModel implements VRcontract.Model {
}
