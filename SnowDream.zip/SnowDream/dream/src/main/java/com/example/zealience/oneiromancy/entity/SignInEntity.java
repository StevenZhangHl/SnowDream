package com.example.zealience.oneiromancy.entity;

/**
 * @user steven
 * @createDate 2019/3/14 17:58
 * @description 自定义
 */
public class SignInEntity {
    private String createTime;
    private int points;

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public SignInEntity(String createTime, int points) {
        this.createTime = createTime;
        this.points = points;
    }
}
