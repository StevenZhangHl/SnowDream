package com.example.zealience.oneiromancy.constant;

/**
 * @user steven
 * @createDate 2019/3/8 09:28
 * @description 存放网页链接
 */
public class UrlConstant {
    public static final String URL_MYGITHUB_HOME = "https://github.com/steven945";
    public static final String url_app_adv_photo = "http://sjbz.fd.zol-img.com.cn/t_s480x800c/g5/M00/00/04/ChMkJ1fJWFiIH_xjAAf28G2nvpoAAU-JQH-Dx0AB_cI468.jpg";
    public static final String url_app_adv_function = "https://www.pgyer.com/i4H2";
}
