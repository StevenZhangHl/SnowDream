package com.example.zealience.oneiromancy.mvp.model;

import com.example.zealience.oneiromancy.mvp.contract.LoginContract;

/**
 * @user steven
 * @createDate 2019/3/6 10:34
 * @description 自定义
 */
public class LoginModel implements LoginContract.Model {
}
