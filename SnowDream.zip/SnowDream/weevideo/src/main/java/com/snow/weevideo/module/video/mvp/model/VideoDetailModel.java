package com.snow.weevideo.module.video.mvp.model;

import com.snow.weevideo.module.video.mvp.contract.VideoDetailContract;

/**
 * @user steven
 * @createDate 2019/6/28 09:38
 * @description 自定义
 */
public class VideoDetailModel implements VideoDetailContract.Model {
}
